
exp=0.04
nproj=6000

for iter in {0..9}
do
echo "     "
echo "Running iteration $iter"

for heightstep in {0..5}
   do
      scanname=`printf "diplacanthus_h%d_c%d" $heightstep $iter`
      (( height = 6 * $heightstep ))
      caput -cw 300  BL12I-MO-TAB-02:ST1:Y3.VAL $height
      echo "reached height $height"
      echo "scanning $scanname"
      fossil_apr_2012.py $scanname $nproj $exp
   done
done



dark.py diplacanthus 25 $exp 0 1
